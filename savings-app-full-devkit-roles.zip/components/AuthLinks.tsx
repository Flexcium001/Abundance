'use client';
import { useEffect, useState } from 'react';
export default function AuthLinks() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  useEffect(() => { (async () => { const res = await fetch('/api/plan'); setAuthed(res.status !== 401); })(); }, []);
  if (authed === null) return null;
  return <div className="text-sm">{authed ? <a className="underline" href="/api/auth/signout">Sign out</a> : <a className="underline" href="/api/auth/signin">Sign in</a>}</div>;
}
