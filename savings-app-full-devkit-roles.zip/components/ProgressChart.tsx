'use client';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import type { PlanEntry } from '@/types';
function toCumulative(entries: PlanEntry[]) { let p=0,a=0; return [...entries].sort((x,y)=>x.weekNumber-y.weekNumber).map(e=>{p+=Number(e.plannedAmount); a+=Number(e.actualAmount||0); return {week:e.weekNumber, planned:p, actual:a};}); }
export default function ProgressChart({ entries }: { entries: PlanEntry[] }) {
  const data = toCumulative(entries);
  return (<div style={{width:'100%',height:280}}><ResponsiveContainer><LineChart data={data}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="week"/><YAxis/><Tooltip/><Legend/><Line type="monotone" dataKey="planned" dot={false}/><Line type="monotone" dataKey="actual" dot={false}/></LineChart></ResponsiveContainer></div>);
}
