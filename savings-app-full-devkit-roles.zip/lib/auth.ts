import NextAuth, { type NextAuthConfig } from "next-auth";
import Google from "next-auth/providers/google";
export const authConfig = { session: { strategy: "jwt" }, providers: [Google] } satisfies NextAuthConfig;
export const { handlers, auth } = NextAuth(authConfig);
