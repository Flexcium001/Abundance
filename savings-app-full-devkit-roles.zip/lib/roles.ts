import { prisma } from '@/lib/prisma';
import { auth } from '@/lib/auth';

export type RoleName = 'USER' | 'ADMIN' | 'SUPERADMIN';

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.email) return { user: null };
  const email = session.user.email as string;
  const user = await prisma.user.upsert({
    where: { email },
    create: { email, name: session.user.name ?? null, image: session.user.image ?? null },
    update: { name: session.user.name ?? undefined, image: session.user.image ?? undefined }
  });
  return { user };
}

export async function requireRole(minRole: RoleName) {
  const { user } = await requireUser();
  if (!user) return { user: null, authorized: false };
  const order: Record<RoleName, number> = { USER: 1, ADMIN: 2, SUPERADMIN: 3 };
  const ok = order[user.role as RoleName] >= order[minRole];
  return { user, authorized: ok };
}
