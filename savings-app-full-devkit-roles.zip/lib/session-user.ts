import { auth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
export async function requireUser() {
  const session = await auth();
  if (!session?.user?.email) return { user: null };
  const email = session.user.email as string;
  const user = await prisma.user.upsert({
    where: { email },
    create: { email, name: session.user.name ?? null, image: session.user.image ?? null },
    update: { name: session.user.name ?? undefined, image: session.user.image ?? undefined }
  });
  return { user };
}
