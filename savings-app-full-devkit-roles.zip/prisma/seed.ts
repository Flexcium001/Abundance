import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
async function main() {
  const user = await prisma.user.upsert({ where: { email: "dev@example.com" }, update: {}, create: { email: "dev@example.com", name: "Dev User", role: "SUPERADMIN" } });
  const baseAmount = 100; const startDate = new Date();
  const plan = await prisma.plan.create({ data: { userId: user.id, planType: "FIXED", baseAmount, startDate } });
  const entries = Array.from({ length: 52 }).map((_, i) => ({ planId: plan.id, weekNumber: i+1, dueDate: new Date(startDate.getTime() + 7*24*60*60*1000*i), plannedAmount: baseAmount }));
  await prisma.planEntry.createMany({ data: entries });
  console.log("Seed complete.");
}
main().finally(()=>prisma.$disconnect());
