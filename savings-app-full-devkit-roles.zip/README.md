# 52-Week Savings App — Full + DevKit + Roles

Features:
- Google login (NextAuth)
- 52-week plan (fixed/ladder/reverse)
- CSV export
- Daily reminders (Vercel Cron @ 09:00 Europe/Stockholm)
- Optional email reminders (SMTP)
- Progress chart (Recharts)
- Roles: USER / ADMIN / SUPERADMIN
- Admin dashboard + admin APIs
- DevKit: docs, linting, CI, env validation, Docker

## Quick Start

```bash
pnpm i
cp .env.example .env.local
# Fill in DATABASE_URL, NEXTAUTH_*, GOOGLE_*, CRON_SECRET, and SMTP if you want emails
pnpm prisma:generate
pnpm prisma:migrate
pnpm dev
```

Open http://localhost:3000

## Deploy to Vercel
- Create Vercel Postgres → set `DATABASE_URL`
- Set env vars (`NEXTAUTH_SECRET`, `NEXTAUTH_URL`, `GOOGLE_*`, `CRON_SECRET`, SMTP optional)
- `vercel.json` cron is included below.

## Cron
`vercel.json`:
```json
{
  "crons": [
    {
      "path": "/api/cron/due",
      "schedule": "0 9 * * *",
      "headers": { "Authorization": "Bearer ${CRON_SECRET}" },
      "timezone": "Europe/Stockholm"
    }
  ]
}
```

## Roles
Promote a user via SQL:
```sql
UPDATE "User" SET role='ADMIN' WHERE email='you@example.com';
-- or 'SUPERADMIN'
```
