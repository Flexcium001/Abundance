# Architecture Overview

Next.js + Prisma + NextAuth + Tailwind + Recharts + Nodemailer + Vercel Cron.
