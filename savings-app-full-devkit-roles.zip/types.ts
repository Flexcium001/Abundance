export type PlanEntry = { id: string; weekNumber: number; dueDate: string; plannedAmount: number; actualAmount: number; status: 'DUE'|'PAID'|'MISSED' };
export type PlanSummary = { currency: string; plannedTotal: number; savedTotal: number; completionPct: number; weeksRemaining: number; nextDue: PlanEntry|null; recent: PlanEntry[]; };
export type PlanSummaryFull = { currency: string; entries: PlanEntry[]; };
