# API Reference

See /app/api/* for routes. Protected by NextAuth; admin routes use role guards.
