---
name: Feature request
about: Suggest an idea for this project
---

**Problem**

**Proposed solution**

**Alternatives**

**Additional context**
