# Developer Guide

Use pnpm, run lint/typecheck/build in CI. Conventional commits recommended.
