'use client';
import { useEffect, useState } from 'react';
import type { PlanSummary, PlanEntry } from '@/types';
import ProgressChart from '@/components/ProgressChart';
export default function Page() {
  const [summary, setSummary] = useState<PlanSummary | null>(null);
  const [entries, setEntries] = useState<PlanEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [unauth, setUnauth] = useState(false);
  useEffect(()=>{(async()=>{try{const res=await fetch('/api/plan',{cache:'no-store'}); if(res.status===401){setUnauth(true);return;} if(!res.ok) throw new Error('Failed to load plan'); const data=await res.json(); setSummary(data.summary); setEntries(data.entries||[]);}catch(e:any){setError(e.message);}finally{setLoading(false);}})();},[]);
  if(loading) return <div>Loading…</div>;
  if(unauth) return <div className="card"><h1 className="text-xl font-semibold mb-2">Welcome</h1><p className="mb-4">Please sign in to create and view your 52-week savings plan.</p><a className="btn btn-primary" href="/api/auth/signin">Sign in with Google</a></div>;
  if(error) return <div className="text-red-600">{error}</div>;
  if(!summary) return <div className="card"><h1 className="text-xl font-semibold mb-2">Welcome</h1><p className="mb-4">Create your 52-week plan to get started.</p><a className="btn btn-primary" href="/plan">Create Plan</a></div>;
  return (<div className="grid gap-4 md:grid-cols-2">
    <div className="card"><h2 className="text-lg font-semibold mb-2">Progress</h2><div className="text-sm">
      <div>Planned Total: {summary.currency} {summary.plannedTotal}</div>
      <div>Saved Total: {summary.currency} {summary.savedTotal}</div>
      <div>Completion: {summary.completionPct}%</div>
      <div>Weeks Remaining: {summary.weeksRemaining}</div>
    </div></div>
    <div className="card"><h2 className="text-lg font-semibold mb-2">This Week</h2>{summary.nextDue?
      <div className="text-sm">
        <div>Week {summary.nextDue.weekNumber} due on {new Date(summary.nextDue.dueDate).toLocaleDateString()}</div>
        <div>Planned: {summary.currency} {summary.nextDue.plannedAmount}</div>
        <form className="mt-3" onSubmit={async(e:any)=>{e.preventDefault();const actual=e.target.actual.value||summary.nextDue!.plannedAmount;const res=await fetch(`/api/entry/${summary.nextDue!.id}/pay`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({actualAmount:Number(actual)})}); if(res.ok) location.reload();}}>
          <input name="actual" type="number" step="0.01" className="border rounded-lg px-3 py-2 mr-2" placeholder="Actual amount"/>
          <button className="btn btn-primary">Mark as Paid</button>
        </form>
      </div> : <div className="text-sm">No due item this week 🎉</div>}</div>
    <div className="card md:col-span-2"><h2 className="text-lg font-semibold mb-2">Cumulative progress</h2>{entries.length===0?<div className="text-sm">No data yet.</div>:<ProgressChart entries={entries}/>}</div>
    <div className="card md:col-span-2"><h2 className="text-lg font-semibold mb-2">History (recent)</h2>{summary.recent.length===0?<div className="text-sm">No payments yet.</div>:(
      <table className="table"><thead><tr><th>Week</th><th>Date</th><th>Planned</th><th>Actual</th><th>Status</th></tr></thead><tbody>
        {summary.recent.map(r=>(<tr key={r.id}><td>{r.weekNumber}</td><td>{new Date(r.dueDate).toLocaleDateString()}</td><td>{summary.currency} {r.plannedAmount}</td><td>{summary.currency} {r.actualAmount}</td><td>{r.status}</td></tr>))}
      </tbody></table>
    )}</div>
  </div>);
}
