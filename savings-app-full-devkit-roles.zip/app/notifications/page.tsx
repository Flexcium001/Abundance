import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/session-user';
export default async function NotificationsPage() {
  const { user } = await requireUser();
  if (!user) return <div className="card">Please sign in to view notifications.</div>;
  const notes = await prisma.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } });
  return (<div className="card"><h1 className="text-xl font-semibold mb-3">Notifications</h1>
    {notes.length===0?<div className="text-sm">No notifications.</div>:<ul className="space-y-2">
      {notes.map(n=>(<li key={n.id} className="border rounded-xl p-3"><div className="text-sm font-medium">{n.title}</div><div className="text-xs text-gray-600">{new Date(n.createdAt).toLocaleString()}</div><div className="text-sm">{n.body}</div></li>))}
    </ul>}
  </div>);
}
