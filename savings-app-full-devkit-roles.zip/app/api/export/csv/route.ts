import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/session-user';
export async function GET() {
  const { user } = await requireUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const plan = await prisma.plan.findFirst({ where: { userId: user.id, isActive: true }, include: { entries: { orderBy: { weekNumber: 'asc' } } } });
  if (!plan) return NextResponse.json({ error: 'No active plan' }, { status: 404 });
  const rows = [['week_number','due_date','planned_amount','actual_amount','status']];
  for (const e of plan.entries) rows.push([ String(e.weekNumber), new Date(e.dueDate).toISOString().slice(0,10), String(e.plannedAmount), String(e.actualAmount ?? 0), e.status ]);
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  return new NextResponse(csv, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="savings_plan.csv"' } });
}
