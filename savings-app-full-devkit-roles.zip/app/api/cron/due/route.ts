import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/mailer';
function isAuthorized(req: NextRequest) { const header = req.headers.get('authorization') || ''; const token = header.replace(/^Bearer\s+/i, ''); const expected = process.env.CRON_SECRET; return expected && token === expected; }
export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const todayStart = new Date(); todayStart.setHours(0,0,0,0);
  const todayEnd = new Date(); todayEnd.setHours(23,59,59,999);
  const dueEntries = await prisma.planEntry.findMany({ where: { status: { in: ['DUE','MISSED'] }, dueDate: { gte: todayStart, lte: todayEnd }, plan: { isActive: true } }, include: { plan: { include: { user: true } } } });
  let created=0, emailed=0;
  for (const e of dueEntries) {
    await prisma.notification.create({ data: { userId: e.plan.userId, title: `Week ${e.weekNumber} is due today`, body: `Planned amount: ${e.plannedAmount}` } });
    created++;
    const user = e.plan.user;
    if (user?.emailReminders && user.email) {
      try { await sendEmail(user.email, `Savings reminder: Week ${e.weekNumber} due today`, `Hi ${user.name ?? ''},\n\nYour 52-week savings plan has a due item today. Planned amount: ${e.plannedAmount}.\n\n— 52-Week Savings App`); emailed++; } catch {}
    }
  }
  return NextResponse.json({ ok: true, created, emailed });
}
