import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/session-user';
export async function POST(req: NextRequest, { params }: { params: { id: string }}) {
  const { user } = await requireUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { id } = params;
  const body = await req.json().catch(() => ({}));
  const actualAmount = Number(body.actualAmount ?? 0);
  const entry = await prisma.planEntry.findUnique({ where: { id }, include: { plan: true } });
  if (!entry || entry.plan.userId !== user.id) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  const updated = await prisma.planEntry.update({ where: { id }, data: { status: 'PAID', actualAmount: actualAmount > 0 ? actualAmount : entry.plannedAmount } });
  return NextResponse.json({ ok: true, entry: updated });
}
