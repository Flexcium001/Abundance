import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireRole } from '@/lib/roles';
export async function GET() {
  const { authorized } = await requireRole('ADMIN');
  if (!authorized) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const users = await prisma.user.findMany({ orderBy: { createdAt: 'desc' }, select: { id:true, email:true, name:true, role:true, createdAt:true }, take: 200 });
  return NextResponse.json({ users });
}
