import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireRole } from '@/lib/roles';
export async function POST(req: NextRequest) {
  const { authorized } = await requireRole('SUPERADMIN');
  if (!authorized) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const { email, role } = await req.json();
  if (!email || !['USER','ADMIN','SUPERADMIN'].includes(role)) return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
  await prisma.user.update({ where: { email }, data: { role } as any });
  return NextResponse.json({ ok: true });
}
