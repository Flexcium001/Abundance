import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/session-user';
function addDays(date: Date, days: number) { const d = new Date(date); d.setDate(d.getDate() + days); return d; }
export async function GET() {
  const { user } = await requireUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const plan = await prisma.plan.findFirst({ where: { userId: user.id, isActive: true }, include: { entries: { orderBy: { weekNumber: 'asc' } } } });
  if (!plan) return NextResponse.json({ summary: null, entries: [] });
  const currency = user.currency || 'SEK';
  const plannedTotal = plan.entries.reduce((s,e)=>s+Number(e.plannedAmount),0);
  const savedTotal = plan.entries.reduce((s,e)=>s+Number(e.actualAmount||0),0);
  const paid = plan.entries.filter(e=>e.status==='PAID').length;
  const completionPct = Math.round((paid/52)*100);
  const weeksRemaining = Math.max(52-paid,0);
  const now = new Date();
  const nextDue = plan.entries.find(e=>e.status!=='PAID' && new Date(e.dueDate) >= addDays(now,-6)) || null;
  const recent = plan.entries.filter(e=>e.status==='PAID').slice(-10);
  return NextResponse.json({ summary:{currency,plannedTotal,savedTotal,completionPct,weeksRemaining,nextDue,recent}, entries: plan.entries });
}
export async function POST(req: NextRequest) {
  const { user } = await requireUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const body = await req.json(); const { baseAmount, planType, startDate } = body as { baseAmount:number, planType:'FIXED'|'LADDER'|'REVERSE_LADDER', startDate?:string };
  if (!baseAmount || !planType) return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
  await prisma.plan.updateMany({ where: { userId: user.id, isActive: true }, data: { isActive: false } });
  const start = startDate ? new Date(startDate) : new Date();
  const plan = await prisma.plan.create({ data: { userId: user.id, planType, baseAmount, startDate: start } });
  const entries = Array.from({ length: 52 }).map((_, i) => {
    const weekNumber = i + 1; let plannedAmount = baseAmount;
    if (planType === 'LADDER') plannedAmount = baseAmount * weekNumber;
    if (planType === 'REVERSE_LADDER') plannedAmount = baseAmount * (53 - weekNumber);
    const dueDate = new Date(start); dueDate.setDate(dueDate.getDate() + (7 * i));
    return { planId: plan.id, weekNumber, dueDate, plannedAmount };
  });
  await prisma.planEntry.createMany({ data: entries });
  return NextResponse.json({ ok: true });
}
